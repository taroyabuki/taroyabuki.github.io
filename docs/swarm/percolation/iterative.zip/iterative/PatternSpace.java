import swarm.space.*;
import swarm.defobj.*;
import swarm.*;
import java.util.*;

public class PatternSpace extends Discrete2dImpl{
	int width,height;
	
	LinkedList remainingPoints;
	HashMap clusterSizeData;
	HashMap overlup;
	int[][] data;
	int clusterIndex;
	int largestClusterIndex;
	int largestClusterSize;
	boolean checked[][];

	public PatternSpace(Zone aZone,int W,int H){
		super(aZone,W,H);
		width=W;
		height=H;
		initializeSpace();
	}
	
	public void initializeSpace(){
		data=new int[width][height];
		clusterIndex=0;
		largestClusterIndex=0;
		
		remainingPoints=new LinkedList();
		for(int i=0;i<height;++i){
			for(int j=0;j<width;++j){
				int[] pair={i,j};
				remainingPoints.add(pair);
				data[i][j]=0;
				this.putValue$atX$Y(0,i,j);
			}
		}
		
		clusterSizeData=new HashMap();
		overlup=new HashMap();
	}
	
	/**
	 * �܂��_�̒u����Ă��Ȃ��i�q�����邩
	 */
	public boolean remainingQ(){
		return !remainingPoints.isEmpty();
	}
	
	/**
	 * PatternSpace�ɐV�����_�������_���ɒǉ�����B
	 */
	public void update(){
		int pIndex=Globals.env.uniformIntRand.getIntegerWithMin$withMax(0,remainingPoints.size()-1);
		int[] p=(int[])remainingPoints.get(pIndex);
		remainingPoints.remove(pIndex);
		int i=p[0];
		int j=p[1];
		data[i][j]=++clusterIndex;
		
		updatePatternSpace();
	}
	
	public void updatePatternSpace(){
		for(int i=0;i<height;++i)
			for(int j=0;j<width;++j){
				int tmp=data[i][j];
				if(tmp!=0){
					if(tmp==largestClusterIndex) putValue$atX$Y(2,i,j);
					else putValue$atX$Y(1,i,j);
				}
			}
	}
	
	
	public void clustering(){
		overlup.clear();
		trace();
		
		for(int i=0;i<height;++i){
			for(int j=0;j<width;++j){
				Integer tmp;
				while(overlup.containsKey(tmp=new Integer(data[i][j])))
					data[i][j]=((Integer)overlup.get(tmp)).intValue();
			}
		}
		
		fixClusterSize();
		fixLargestClusterSize();
	}

	/**
	 * clustering�̕⏕���\�b�h�B
	 */
	void trace(){
		for(int i=0;i<height;++i){
			for(int j=0;j<width;++j){
				if(data[i][j]!=0){
					data[i][j]=newValue(i,j);
				}
			}
		}
	}
	
	/**
	 * trace�̕⏕���\�b�h�B�_�ɑ΂��Ăǂ������C���f�b�N�X�����邩�����߂�B
	 */
	int newValue(int i,int j){
		int left,up;
		
		if(i==0) up=0;
		else up=data[i-1][j];
		if(j==0) left=0;
		else left=data[i][j-1];
		
		if(left==0&&up==0) return ++clusterIndex;
		else if(left!=0&&up==0) return left;
		else if(left==0&&up!=0) return up;
		else if(left==up) return up;
		else{
			Integer min=new Integer(java.lang.Math.min(left,up));
			Integer max=new Integer(java.lang.Math.max(left,up));
			overlup.put(max,min);//�ق�Ƃ��͂����ƍׂ����w�肵���ق���������������Ȃ����ʓ|
			return min.intValue();
		}
	}
	
	/**
	 * ���ׂẴN���X�^�̃T�C�Y�����߂�B
	 */
	void fixClusterSize(){
		clusterSizeData.clear();
		
		int tmpData=0;
		for(int i=0;i<height;++i){
			for(int j=0;j<width;++j){
				tmpData=data[i][j];
				if(tmpData!=0){
					Integer tmp=new Integer(tmpData);
					if(clusterSizeData.containsKey(tmp)){
						clusterSizeData.put(tmp,new Integer(1+
							((Integer)clusterSizeData.get(tmp)).intValue()));
					} else {
						clusterSizeData.put(tmp,new Integer(1));
					}
				}
			}
		}
	}
	
	/**
	 * �ő�N���X�^�̃T�C�Y�����߂�B
	 */
	void fixLargestClusterSize(){
		Integer max=new Integer(0);
		Integer tmpSize;
		Object tmpIndex;
		Iterator it=clusterSizeData.keySet().iterator();
		while(it.hasNext()){
			tmpIndex=it.next();
			tmpSize=(Integer)clusterSizeData.get(tmpIndex);
			if(max.compareTo(tmpSize)<0){
				max=tmpSize;
				largestClusterIndex=((Integer)tmpIndex).intValue();
			}
		}
		largestClusterSize=max.intValue();
	}
	
	public double getPercolationProb(){
		return (double)largestClusterSize/(width*height);
	}
	
	public int getClusterNum(){
		return clusterSizeData.size();
	}
	
	public Collection getClusterSizeData(){
		return clusterSizeData.values();
	}
}
